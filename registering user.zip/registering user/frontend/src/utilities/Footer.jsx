import React from "react";

function Footer(){
    return(
        <>
        This is footer component
        </>
    )
}

export default Footer;

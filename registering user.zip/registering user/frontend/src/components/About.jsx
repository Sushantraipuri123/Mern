import React from "react";

function About(){
    return (
        <>
        <h1>This is about page</h1>
        </>
    )
}

export default About
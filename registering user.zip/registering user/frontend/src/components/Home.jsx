import React from "react";

function Home(){
    return(
        <>
        <div className="m-5">
        This is home
        </div>
        </>
    )
}

export default Home
